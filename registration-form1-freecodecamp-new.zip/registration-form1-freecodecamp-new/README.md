# Registration form1 (freecodecamp new)

A Pen created on CodePen.io. Original URL: [https://codepen.io/jansofta/pen/mdLNNYq](https://codepen.io/jansofta/pen/mdLNNYq).

